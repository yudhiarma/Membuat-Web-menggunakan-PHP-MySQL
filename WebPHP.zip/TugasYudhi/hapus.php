<?php
include 'koneksi.php';
$NIP = $_GET['id'];
mysql_query("DELETE FROM tb31 WHERE NIP='$NIP'")or die(mysql_error());
header("location:index.php?pesan=hapus");
?>