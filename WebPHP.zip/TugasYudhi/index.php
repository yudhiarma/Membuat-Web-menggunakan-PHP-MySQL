<!DOCTYPE html>
<html>
<head>
    <title>Praktikum Pemrograman Web</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <div class="judul">
        <h1>Praktikum Pemrograman Web</h1>
        <h1>Politeknik Negeri Batam</h1>
    </div>
    <br/>
        <h2>Data Pegawai</h2>
    <a class="tombol" href="input.php">+ Tambah Data Pegawai Baru</a>
    <br/>
    <br/>
   
    <table border="7" class="table">
        <tr>
            <th>No</th>
            <th>NIP</th>
            <th>Nama</th>
            <th>Alamat</th>
            <th>Agama</th>
            <th>Email</th>
            <th>Opsi</th>
        <?php
        include "koneksi.php";
        $query_mysql = mysql_query("SELECT * FROM tb31") or die (mysql_error());
        $nomor = 1;
        while($data = mysql_fetch_array($query_mysql)){
        ?>
        <tr>
            <td><?php echo $nomor++; ?></td>
            <td><?php echo $data['NIP']; ?></td>
            <td><?php echo $data['Nama']; ?></td>
            <td><?php echo $data['Alamat']; ?></td>
            <td><?php echo $data['Agama']; ?></td>
            <td><?php echo $data['Email']; ?></td>
        <td>
            <a class="edit" href="edit.php?id=<?php echo $data['NIP']; ?>">Edit</a>
            <a class="hapus" href="hapus.php?id=<?php echo $data['NIP']; ?>">Hapus</a>
        </td>
        </tr>
        <?php } ?>
        <?php
        if(isset($_GET['pesan'])){
            $pesan = $_GET['pesan'];
            if($pesan == "input"){
                echo "Data berhasil di input.";
            }else if ($pesan == "update"){
                echo "Data berhasil di update.";
            }else if($pesan == "hapus"){
                echo "Data berhasil di hapus.";
            }
        }
        ?>
</body> 
</html>