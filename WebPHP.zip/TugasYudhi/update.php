<?php
include 'koneksi.php';
$nip = $_POST['nip'];
$nama = $_POST['nama'];
$alamat = $_POST['alamat'];
$agama = $_POST['agama'];
$email = $_POST['email'];

mysql_query("UPDATE tb31 SET Nama='$nama', Alamat='$alamat',  Agama='$agama',  Email='$email' WHERE NIP='$nip'");
header("location:index.php?pesan=update");
?>