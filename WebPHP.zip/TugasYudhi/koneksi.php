<?php
//membuat variabel yang berisi tentang data / path database
$local = "localhost";
$user = "root";
$pass = "";
$dbnm = "3311801031";

//variabel "host" untuk koneksi ke database
$host = mysql_connect($local,$user,$pass);

//error handling
//jika database tidak terhubung
if($host){
    $db = mysql_select_db($dbnm);
        if(!$db){
            die("Database tidak dapat dibuka");
        }
        } else {
            die("Server MySQL tidak terhubung");
        }
?>