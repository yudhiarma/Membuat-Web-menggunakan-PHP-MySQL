<!DOCTYPE html>
<html>
<head>
    <title>Praktikum Pemrograman Web</title>
    <link rel="stylesheet" type="text/css" href="style.css">
    <script language="javascript">
    function cekform(){
        //ini untuk mengecek formnya (semua form tidak boleh kosong)
        if(document.mhs.txtnip.value==""){
            alert('NIP Harus Diisi');
            document.mhs.txtnip.focus();
            return false;
        }else if(document.mhs.txtnama.value==""){
            alert('Nama Harus Diisi');
            document.mhs.txtnama.focus();
            return false;
        }else if(document.mhs.txtalamat.value==""){
            alert('Alamat Harus Diisi');
            document.mhs.txtalamat.focus();
            return false;
        }else if(document.mhs.txtagama.value==""){
            alert('Agama Harus Diisi');
            document.mhs.txtagama.focus();
            return false;
        }else if(document.mhs.txtemail.value==""){
            alert('Email Harus Diisi');
            document.mhs.txtemail.focus();
            return false;
        }else {
            return true;
        }
    }
    </script>
</head>
<body>
    <div class="judul">
        <h1>Praktikum Pemrograman Web</h1>
        <h2>Politeknik Negeri Batam</h2>
    </div>
    <br/>
    <a href="index.php">Lihat Semua Data Pegawai</a>
    <br/>
    <h2>Input data baru</h2>
    <form action="input-aksi.php" name="mhs" method="post" onsubmit="return cekform()">
        <table>
            <tr>
                <td>NIP</td>
                <td><input type="text" id="txtnip" name="NIP"></td>
            </tr>
            <tr>
                <td>Nama</td>
                <td><input type="text" id="txtnama" name="Nama"></td>
            </tr>
            <tr>
                <td>Alamat</td>
                <td><input type="text" id="txtalamat" name="Alamat"></td>
            </tr>
            <tr>
                <td>Agama</td>
                <td><input type="text" id="txtagama" name="Agama"></td>
            </tr>
            <tr>
                <td>Email</td>
                <td><input type="text" id="txtemail" name="Email"></td>
            </tr>
            <tr>
                <td></td>
                <td><input type="submit" value="Simpan"></td>
            </tr>
        </table>
        </form>
</body>
</html>