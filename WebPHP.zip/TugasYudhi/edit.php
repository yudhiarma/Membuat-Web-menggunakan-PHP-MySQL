<!DOCTYPE html>
<html>
<head>
    <title>Praktikum Pemrograman Web</title>
    <link rel="stylesheet" type="text/css" href="style.css">
    <script language="javascript">
    function cekform(){
        //ini untuk mengecek formnya (semua form tidak boleh kosong)
        if(document.mhs.txtnip.value==""){
            alert('NIP Harus Diisi');
            document.mhs.txtnip.focus();
            return false;
        }else if(document.mhs.txtnama.value==""){
            alert('Nama Harus Diisi');
            document.mhs.txtnama.focus();
            return false;
        }else if(document.mhs.txtalamat.value==""){
            alert('Alamat Harus Diisi');
            document.mhs.txtalamat.focus();
            return false;
        }else if(document.mhs.txtagama.value==""){
            alert('Agama Harus Diisi');
            document.mhs.txtagama.focus();
            return false;
        }else if(document.mhs.txtemail.value==""){
            alert('Email Harus Diisi');
            document.mhs.txtemail.focus();
            return false;
        }else {
            return true;
        }
    }
    </script>
</head>
<body>
    <div class="judul">
        <h1>Praktikum Pemrograman Web</h1>
        <h2>Politeknik Negeri Batam</h2>
    </div>
    <br/>
    <a href="index.php">Lihat Semua Data Pegawai</a>
    <br/>
    <h2>Edit Data Pegawai</h2>
    <?php
    include "koneksi.php";
    $NIP = $_GET['id'];
    $query_mysql = mysql_query("SELECT * FROM tb31 WHERE NIP='$NIP'")or die (mysql_error());
    $nomor = 1;
    while ($data = mysql_fetch_array($query_mysql)){
    ?>
    <form action="update.php" method="post">
        <table>
            <tr>
                <td>NIP</td>
                <td>
                    <input type="hidden" name="id" value="<?php echo $data['id'] ?>">
                    <input type="text" name="nip" value="<?php echo $data['NIP'] ?>">
                </td>
            </tr>
            <tr>
                <td>Nama</td>
                <td><input type="text" name="nama" value="<?php echo $data['Nama'] ?>"></td>
            </tr>
            <tr>
                <td>Alamat</td>
                <td><input type="text" name="alamat" value="<?php echo $data['Alamat'] ?>"></td>
            </tr>
            <tr>
                <td>Agama</td>
                <td><input type="text" name="agama" value="<?php echo $data['Agama'] ?>"></td>
            </tr>
            <tr>
                <td>Email</td>
                <td><input type="text" name="email" value="<?php echo $data['Email'] ?>"></td>
            </tr>
            <tr>
                <td></td>
                <td><input type="submit" value="Simpan"></td>
            </tr>
        </table>
    </form>
    <?php } ?>
</body>
</html>