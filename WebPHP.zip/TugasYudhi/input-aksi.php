<?php
include 'koneksi.php';
$nip = $_POST['NIP'];
$nama = $_POST['Nama'];
$alamat = $_POST['Alamat'];
$agama = $_POST['Agama'];
$email = $_POST['Email'];


mysql_query("INSERT INTO tb31 VALUES('$nip','$nama','$alamat','$agama','$email')");
header("location:index.php?pesan=input");
?>